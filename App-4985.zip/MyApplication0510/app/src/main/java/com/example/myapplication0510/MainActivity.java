package com.example.myapplication0510;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void navigateToAddBook(View view) {
        Intent intent = new Intent(this, AddBook.class);
        startActivity(intent);
    }

    public void navigateToAddMember(View view) {
        Intent intent = new Intent(this, AddMember.class);
        startActivity(intent);
    }
    public void navigateToViewBook(View view) {
        Intent intent = new Intent(this, BookManagement.class);
        startActivity(intent);
    }

    public void navigateToViewMember(View view) {
        Intent intent = new Intent(this, MemberManagement.class);
        startActivity(intent);
    }



}
